//
//  HospitalsViewController.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 29/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit


class HospitalsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
    var hospitalname = [String]()
    var hospitalVicinity = [String]()
    var hospitalRating = [String]()
    
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    
    var selectedIndex = Int()
    

    @IBOutlet weak var HospitalsTableView: UITableView!
    override func viewDidLoad() {
    super.viewDidLoad()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
        HospitalsTableView.dataSource = self
        HospitalsTableView.delegate = self
        navigationItem.title = "HOSPITALS"

    }
    
    override func viewWillAppear(_ animated: Bool) {
        parseHospitalsData()
    }

    func parseHospitalsData(){
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=hospital&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let HospitalsData = fetchedData["results"]as? [NSDictionary]{
                        for item in HospitalsData{
                            let hospitalsresult = Hospitals()
                            
                            if let name = item["name"] as? String {
                                hospitalsresult.name = name
                             //   self.hospitalname.append(hospitalsresult.name)
                             //   print(self.hospitalname)
                            }
                            if let vicinity = item["vicinity"] as? String{
                                hospitalsresult.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                hospitalsresult.rating = String(describing: rating)
                            }
                            
                            self.hospitalname.append(hospitalsresult.name)
                            self.hospitalVicinity.append(hospitalsresult.vicinity)
                            self.hospitalRating.append(hospitalsresult.rating)
                         //   print(hospitalsresult.name)
                         //   print(hospitalsresult.vicinity)
                         //   print(hospitalsresult.rating)
                        //    print(self.hospitalname)
                            
                            
                        }

                        
                    }
                    self.HospitalsTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hospitalname.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = HospitalsTableView.dequeueReusableCell(withIdentifier: "cell") as! HospitalsTableViewCell
        
        cell.hospitalsName.text = hospitalname[indexPath.item]
        cell.vicinity.text = hospitalVicinity[indexPath.item]
        cell.ratings.text = hospitalRating[indexPath.item]
        if cell.ratings.text
         == "" {
        cell.ratings.text = "Ratings: NA"
        }else{
            cell.ratings.text = "Ratings: "+hospitalRating[indexPath.item]
            
        }

        myActivityIndicator.stopAnimating()
        return cell
        
    }
        func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
     //       let myObject = hospitalname[indexPath.row]
    //    self.selectedIndex = indexPath.row
    //    performSegue(withIdentifier: "1", sender: self)
        
    }
    
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "1"{
            if let IndexPath = self.HospitalsTableView.indexPathForSelectedRow{
             let vc = segue.destination as! MapsViewController
                vc.name = hospitalname[IndexPath.row]
                vc.vicinity = hospitalVicinity[IndexPath.row]
            }
            
        }
    }
//            let vc : MapsViewController = segue.destination as! MapsViewController
//            vc.name = hospitalname[selectedIndex]
//            

}

//
//  gym.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 28/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class Gym: NSObject {
    
    
    var name:String = ""
    var vicinity:String = ""
    var rating:String = ""
    var openNow:String = ""
    
}


//
//  GymViewController.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 29/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class GymViewController: UIViewController,UITableViewDataSource {
    
    var gymname = [String]()
    var gymVicinity = [String]()
    var gymRating = [String]()
    
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)

    @IBOutlet weak var GymTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
        GymTableView.dataSource = self
        navigationItem.title = "GYMS"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        parseGymData()
    }

    
    
    func parseGymData(){
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=gym&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let GymData = fetchedData["results"]as? [NSDictionary]{
                        for item in GymData{
                            var gymresult = Gym()
                            
                            if let name = item["name"] as? String {
                                gymresult.name = name
                            }
                            if let vicinity = item["vicinity"] as? String{
                                gymresult.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                gymresult.rating = String(describing: rating)
                            }
                            
                            self.gymname.append(gymresult.name)
                            self.gymVicinity.append(gymresult.vicinity)
                            self.gymRating.append(gymresult.rating)
                            print(gymresult.name)
                            print(gymresult.vicinity)
                            print(gymresult.rating)
                            
                            }
                
                    }
                    self.GymTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gymname.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = GymTableView.dequeueReusableCell(withIdentifier: "cell") as! GymTableViewCell
        
          cell.gymName.text = gymname[indexPath.item]
          cell.vicinity.text = gymVicinity[indexPath.item]
          cell.ratings.text = gymRating[indexPath.item]
          if cell.ratings.text == "" {
           cell.ratings.text = "Ratings: NA"
          }else{
          cell.ratings.text = "Ratings: "+gymRating[indexPath.item]
        }
          myActivityIndicator.stopAnimating()
          return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "3"{
            if let IndexPath = self.GymTableView.indexPathForSelectedRow{
                let vc = segue.destination as! MapsViewController
                vc.name = gymname[IndexPath.row]
                vc.vicinity = gymVicinity[IndexPath.row]
            }
            
        }
    }



}

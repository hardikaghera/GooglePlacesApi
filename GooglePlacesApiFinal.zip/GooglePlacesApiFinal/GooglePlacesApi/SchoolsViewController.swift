//
//  SchoolsViewController.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 29/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class SchoolsViewController: UIViewController,UITableViewDataSource {

    var schoolname = [String]()
    var schoolVicinity = [String]()
    var schoolRating = [String]()

    
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)

    @IBOutlet weak var SchoolsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
       // parseSchoolsData()
        SchoolsTableView.dataSource = self
        navigationItem.title = "SCHOOLS"
        

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        parseSchoolsData()
    }
    
    func parseSchoolsData(){
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=school&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let SchoolsData = fetchedData["results"]as? [NSDictionary]{
                            for item in SchoolsData{
                            var schoolsresult = Schools()
                            
                                if let name = item["name"] as? String {
                                    schoolsresult.name = name
                                }
                                if let vicinity = item["vicinity"] as? String{
                                    schoolsresult.vicinity = vicinity
                                }
                                if let rating = item["rating"] {
                                    schoolsresult.rating = String(describing: rating)
                                }
                                
                                self.schoolname.append(schoolsresult.name)
                                self.schoolVicinity.append(schoolsresult.vicinity)
                                self.schoolRating.append(schoolsresult.rating)
                                print(schoolsresult.name)
                                print(schoolsresult.vicinity)
                                print(schoolsresult.rating)
                                
                        }
                        
                    }
                    self.SchoolsTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return schoolname.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SchoolsTableView.dequeueReusableCell(withIdentifier: "cell") as! SchoolsTableViewCell
        
        cell.schoolsName.text = schoolname[indexPath.item]
        cell.vicinity.text = schoolVicinity[indexPath.item]
        cell.ratings.text = schoolRating[indexPath.item]
        if cell.ratings.text == ""{
            cell.ratings.text = "Ratings: NA"
        }else{
            cell.ratings.text = "Ratings: " + schoolRating[indexPath.item]
        }
        myActivityIndicator.stopAnimating()
        return cell
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "2"{
            if let IndexPath = self.SchoolsTableView.indexPathForSelectedRow{
                let vc = segue.destination as! MapsViewController
                vc.name = schoolname[IndexPath.row]
                vc.vicinity = schoolVicinity[IndexPath.row]
            }
            
        }
    }



    
}

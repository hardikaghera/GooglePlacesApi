//
//  MapsViewController.swift
//  GooglePlacesApi
//
//  Created by hardik aghera on 02/12/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit
import MapKit

class MapsViewController: UIViewController,UISearchBarDelegate{
    
    
    @IBOutlet weak var searchBar: UISearchBar!
   
    @IBOutlet weak var PlacesMapView: MKMapView!
    var name = String()
    var vicinity = String()
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.delegate = self
    //    print(name)

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        searchBar.text! = name + ", " + vicinity
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(searchBar.text!) { (placemarks:[CLPlacemark]?, error:Error?) in
            if error == nil {
                
                let placemark = placemarks?.first
                let anno = MKPointAnnotation()
                anno.coordinate = (placemark?.location?.coordinate)!
                anno.title = searchBar.text
                let span = MKCoordinateSpanMake(0.1, 0.1)
                let region = MKCoordinateRegion(center: anno.coordinate, span: span)
                
                self.PlacesMapView.setRegion(region, animated: true)
                self.PlacesMapView.addAnnotation(anno)
                self.PlacesMapView.selectAnnotation(anno, animated:true)
                
            }else{
                print(error?.localizedDescription)
            }
        }
    }
    

}

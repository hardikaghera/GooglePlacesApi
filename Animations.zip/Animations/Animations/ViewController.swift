//
//  ViewController.swift
//  Animations
//
//  Created by hardik aghera on 16/12/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var isfrontVisible = true

    @IBOutlet weak var myImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func FlipTapped(_ sender: AnyObject) {
        var option:UIViewAnimationOptions = .transitionFlipFromRight
        if (self.isfrontVisible) {
            self.isfrontVisible = false
            self.myImage.image = UIImage.init(named: "my")
            option = .transitionFlipFromRight
        }else{
            self.isfrontVisible = true
            self.myImage.image = UIImage.init(named: "fb")
            option = .transitionFlipFromLeft
        }
        
        UIView.transition(with: self.myImage, duration: 1.5, options: option, animations: nil, completion: nil)
        
    }
    
    @IBAction func DissoledTapped(_ sender: AnyObject){
        var option:UIViewAnimationOptions = .transitionCrossDissolve
        if (self.isfrontVisible) {
            self.isfrontVisible = false
            self.myImage.image = UIImage.init(named: "my")
            option = .transitionCrossDissolve
        }else{
            self.isfrontVisible = true
            self.myImage.image = UIImage.init(named: "fb")
            option = .transitionCrossDissolve
        }
        
        UIView.transition(with: self.myImage, duration: 1, options: option, animations: nil, completion: nil)
        
    }
    
    @IBAction func CurlTapped(_ sender: AnyObject){
        
        var option:UIViewAnimationOptions = .transitionCurlUp
        if (self.isfrontVisible) {
            self.isfrontVisible = false
            self.myImage.image = UIImage.init(named: "my")
            option = .transitionCurlUp
        }else{
            self.isfrontVisible = true
            self.myImage.image = UIImage.init(named: "fb")
            option = .transitionCurlDown
        }
        
        UIView.transition(with: self.myImage, duration: 1.5, options: option, animations: nil, completion: nil)
        
    }
    
    

}


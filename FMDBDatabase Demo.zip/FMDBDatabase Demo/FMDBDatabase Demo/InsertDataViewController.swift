//
//  InsertDataViewController.swift
//  FMDBDatabase Demo
//
//  Created by Hardik Aghera on 23/02/18.
//  Copyright © 2018 Hardik Aghera. All rights reserved.
//

import UIKit

class InsertDataViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func insertDataButton(_ sender: Any) {
    }
    
    
}

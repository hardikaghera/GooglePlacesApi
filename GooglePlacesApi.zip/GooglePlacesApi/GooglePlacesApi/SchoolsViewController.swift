//
//  SchoolsViewController.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 29/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class SchoolsViewController: UIViewController,UITableViewDataSource {
    var school:[Schools] = []
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)

    @IBOutlet weak var SchoolsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
       // parseSchoolsData()
        SchoolsTableView.dataSource = self
        navigationItem.title = "SCHOOLS"
        

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        parseSchoolsData()
    }
    
    func parseSchoolsData(){
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=school&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let SchoolsData = fetchedData["results"]as? [NSDictionary]{
                            for item in SchoolsData{
                            var schoolsresult = Schools()
                            
                                if let name = item["name"] as? String {
                                    schoolsresult.name = name
                                }
                                if let vicinity = item["vicinity"] as? String{
                                    schoolsresult.vicinity = vicinity
                                }
                                if let rating = item["rating"] {
                                    schoolsresult.rating = String(describing: rating)
                                }
                                
                                self.school.append(schoolsresult)
                                print(schoolsresult.name)
                                print(schoolsresult.vicinity)
                                print(schoolsresult.rating)
                                
                        }
                        
                    }
                    self.SchoolsTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return school.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SchoolsTableView.dequeueReusableCell(withIdentifier: "cell") as! SchoolsTableViewCell
        
        cell.schoolsName.text = school[indexPath.item].name
        cell.vicinity.text = school[indexPath.item].vicinity
        cell.ratings.text = "Ratings: "+school[indexPath.item].rating
        myActivityIndicator.stopAnimating()
        return cell
        
    }


    
}

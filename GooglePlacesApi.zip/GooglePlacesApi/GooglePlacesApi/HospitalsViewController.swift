//
//  HospitalsViewController.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 29/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class HospitalsViewController: UIViewController,UITableViewDataSource {
    var hospital:[Hospitals] = []
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)

    @IBOutlet weak var HospitalsTableView: UITableView!
    override func viewDidLoad() {
    super.viewDidLoad()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
        HospitalsTableView.dataSource = self
        navigationItem.title = "HOSPITALS"

    }
    
    override func viewWillAppear(_ animated: Bool) {
        parseHospitalsData()
    }

    func parseHospitalsData(){
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=hospital&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let HospitalsData = fetchedData["results"]as? [NSDictionary]{
                        for item in HospitalsData{
                            var hospitalsresult = Hospitals()
                            
                            if let name = item["name"] as? String {
                                hospitalsresult.name = name
                            }
                            if let vicinity = item["vicinity"] as? String{
                                hospitalsresult.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                hospitalsresult.rating = String(describing: rating)
                            }
                            
                            self.hospital.append(hospitalsresult)
                            print(hospitalsresult.name)
                            print(hospitalsresult.vicinity)
                            print(hospitalsresult.rating)
                            
                        }

                        
                    }
                    self.HospitalsTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hospital.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = HospitalsTableView.dequeueReusableCell(withIdentifier: "cell") as! HospitalsTableViewCell
        
        cell.hospitalsName.text = hospital[indexPath.item].name
        cell.vicinity.text = hospital[indexPath.item].vicinity
        if cell.ratings.text == nil {
        cell.ratings.text = "Ratings: NA"
        }else{
            cell.ratings.text = "Ratings: "+hospital[indexPath.item].rating
            
        }

        myActivityIndicator.stopAnimating()
        return cell
        
    }


    

}

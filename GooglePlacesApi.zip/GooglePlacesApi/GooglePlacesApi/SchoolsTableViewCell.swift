//
//  SchoolsTableViewCell.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 30/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class SchoolsTableViewCell: UITableViewCell {
    @IBOutlet weak var schoolsPhoto: UIImageView!

    @IBOutlet weak var schoolsName: UILabel!
    @IBOutlet weak var vicinity: UILabel!
    @IBOutlet weak var openNow: UILabel!
    @IBOutlet weak var ratings: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

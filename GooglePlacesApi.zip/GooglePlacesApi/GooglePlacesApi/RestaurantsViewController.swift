//
//  RestaurantsViewController.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 29/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class RestaurantsViewController: UIViewController,UITableViewDataSource {
    var restaurants:[Restaurants] = []
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    


    @IBOutlet weak var RestaurantsTableView: UITableView!
    override func viewDidLoad() {
    super.viewDidLoad()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
        RestaurantsTableView.dataSource = self
        navigationItem.title = "Restuarants"
    
    }
    
    override func viewWillAppear(_ animated: Bool) {
        parseRestaurantData()
    }

    
    func parseRestaurantData(){
        print(ViewController.sharedInst.a)
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=\(ViewController.sharedInst.a),\(ViewController.sharedInst.b)&radius=4000&type=restuarant&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let restaurantData = fetchedData["results"]as? [NSDictionary]{
                        for item in restaurantData{
                            var result = Restaurants()
                            
                            if let name = item["name"] as? String,let vicinity = item["vicinity"] as? String,let ratings = item["rating"]{
                                result.name = name
                                result.vicinity = vicinity
                                result.rating = String(describing: ratings)
                                
                            }
                            self.restaurants.append(result)
                            print(result.name)
                            print(result.vicinity)
                            print(result.rating)
                        }
                        
                    }
                 
                    self.RestaurantsTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurants.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = RestaurantsTableView.dequeueReusableCell(withIdentifier: "cell") as! RestaurantsTableViewCell
        
        cell.name.text = restaurants[indexPath.item].name
        cell.vicinity.text = restaurants[indexPath.item].vicinity
        cell.ratings.text = "Ratings: "+restaurants[indexPath.item].rating
        

        myActivityIndicator.stopAnimating()
        return cell
        
    }


}




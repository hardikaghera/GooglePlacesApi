//
//  ViewController.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 28/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate,UITableViewDataSource  {
    var restaurants:[Restaurants] = []
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    var locationManager:CLLocationManager!
    
    static let sharedInst = ViewController()
    var a = ""
    var b = ""
    
    
    
    
    
    
    @IBOutlet weak var RestaurantsTableView: UITableView!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        parseRestaurantData()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
        RestaurantsTableView.dataSource = self
        navigationItem.title = "RESTUARANTS"
        
        
        

        
      //  parseData()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        determineMyCurrentLocation()
        
    }
    
    func parseRestaurantData(){
        print(ViewController.sharedInst.a)
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=restuarant&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let restaurantData = fetchedData["results"]as? [NSDictionary]{
                        for item in restaurantData{
                            var result = Restaurants()
                            
                            if let name = item["name"] as? String {
                                result.name = name
                            }
                            if let vicinity = item["vicinity"] as? String{
                                result.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                result.rating = String(describing: rating)
                            }
                            
                            self.restaurants.append(result)
                            print(result.name)
                            print(result.vicinity)
                            print(result.rating)
                        }
                        
                    }
                    
                    self.RestaurantsTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }

    
    func determineMyCurrentLocation() {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
            //locationManager.startUpdatingHeading()
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0] as CLLocation
        
        // Call stopUpdatingLocation() to stop listening for location updates,
        // other wise this function will be called every time when user location changes.
        
        // manager.stopUpdatingLocation()
        
        //print("user latitude = \(userLocation.coordinate.latitude)")
        //print("user longitude = \(userLocation.coordinate.longitude)")
        let latitude = userLocation.coordinate.latitude
        let longitude = userLocation.coordinate.longitude
     //   print(latitude)
     //   print(longitude)
    
    
    
        
        
    }
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        print("Error \(error)")
    }
    
    
    

    
    
    
    

    @IBAction func restaurantsTapped(_ sender: Any) {
 //       navigationItem.title = "RESTAURANTS"
//        parseRestaurantData()
    }
    
    @IBAction func gymTapped(_ sender: Any) {
//        navigationItem.title = "GYM"
//        parseGymData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurants.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = RestaurantsTableView.dequeueReusableCell(withIdentifier: "cell") as! RestaurantsTableViewCell
        
        cell.name.text = restaurants[indexPath.item].name
        cell.vicinity.text = restaurants[indexPath.item].vicinity
        cell.ratings.text = "Ratings: "+restaurants[indexPath.item].rating
        
        
        myActivityIndicator.stopAnimating()
        return cell
        
    }


}


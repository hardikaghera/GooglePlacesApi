//
//  HospitalsTableViewCell.swift
//  GooglePlacesApi
//
//  Created by Hardik Aghera on 30/11/17.
//  Copyright © 2017 Hardik Aghera. All rights reserved.
//

import UIKit

class HospitalsTableViewCell: UITableViewCell {

    @IBOutlet weak var hospitalsName: UILabel!
    @IBOutlet weak var vicinity: UILabel!
    @IBOutlet weak var openNow: UILabel!
    @IBOutlet weak var ratings: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

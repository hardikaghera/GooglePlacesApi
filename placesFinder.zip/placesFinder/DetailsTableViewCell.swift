//
//  DetailsTableViewCell.swift
//  placesFinder
//
//  Created by hardik aghera on 23/12/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import UIKit

class DetailsTableViewCell: UITableViewCell {

    @IBOutlet weak var DetailImage: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var vicinity: UILabel!
    @IBOutlet weak var ratings: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        name.sizeToFit()
        vicinity.sizeToFit()
        ratings.sizeToFit()
    }

}

//
//  ViewController.swift
//  placesFinder
//
//  Created by hardik aghera on 23/12/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var DetailsTableView: UITableView!
    @IBOutlet weak var GymButton: UIButton!
    @IBOutlet weak var HospitalButton: UIButton!
    @IBOutlet weak var RestuarantsButton: UIButton!
    @IBOutlet weak var SchoolsButton: UIButton!
    
    var name = [String]()
    var Vicinity = [String]()
    var Rating = [String]()
    
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        parseRestaurantData()
        myActivityIndicator.center = view.center
        myActivityIndicator.startAnimating()
        view.addSubview(myActivityIndicator)
        DetailsTableView.delegate = self
        DetailsTableView.dataSource = self
        navigationItem.title = "RESTUARANTS"
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return name.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = DetailsTableView.dequeueReusableCell(withIdentifier: "cell") as! DetailsTableViewCell
        
        if RestuarantsButton.isEnabled == false{
            cell.DetailImage.image = UIImage(named: "dinner")
        }else if(SchoolsButton.isEnabled == false){
            cell.DetailImage.image = UIImage(named: "classroom")
            
        }else if(GymButton.isEnabled == false){
            cell.DetailImage.image = UIImage(named: "weightlifting")
            
        }else {
            cell.DetailImage.image = UIImage(named: "hospital")
        }
        
        
        cell.name.text = name[indexPath.item]
        cell.vicinity.text = Vicinity[indexPath.item]
        cell.ratings.text = Rating[indexPath.item]
        if cell.ratings.text == "" {
            cell.ratings.text = "Ratings: NA"
        }else{
            cell.ratings.text = "Ratings: " + Rating[indexPath.item]
        }
        
        myActivityIndicator.stopAnimating()
        return cell

    }

    @IBAction func SchoolButtonTapped(_ sender: AnyObject) {
        navigationItem.title = "SCHOOLS"
        name.removeAll()
        Vicinity.removeAll()
        Rating.removeAll()
        parseSchoolData()
        SchoolsButton.isEnabled = false
        RestuarantsButton.isEnabled = true
        GymButton.isEnabled = true
        HospitalButton.isEnabled = true
    
        
    }
    
    @IBAction func RestuarantsButtonTapped(_ sender: AnyObject) {
        navigationItem.title = "RESTUARANTS"
        name.removeAll()
        Vicinity.removeAll()
        Rating.removeAll()
        parseRestaurantData()
        SchoolsButton.isEnabled = true
        RestuarantsButton.isEnabled = false
        GymButton.isEnabled = true
        HospitalButton.isEnabled = true
        
    }
    
    @IBAction func GymButtonTapped(_ sender: AnyObject) {
        navigationItem.title = "GYMS"
        name.removeAll()
        Vicinity.removeAll()
        Rating.removeAll()
        parseGymData()
        SchoolsButton.isEnabled = true
        RestuarantsButton.isEnabled = true
        GymButton.isEnabled = false
        HospitalButton.isEnabled = true
        
        
    }
    
    @IBAction func HospitalButtonTapped(_ sender: AnyObject) {
        navigationItem.title = "HOSPITALS"
        name.removeAll()
        Vicinity.removeAll()
        Rating.removeAll()
        parseHospitalData()
        SchoolsButton.isEnabled = true
        RestuarantsButton.isEnabled = true
        GymButton.isEnabled = true
        HospitalButton.isEnabled = false
        
        
    }
    

    

}


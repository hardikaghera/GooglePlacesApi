//
//  Restuarants.swift
//  placesFinder
//
//  Created by hardik aghera on 23/12/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import UIKit

class Restaurants: NSObject {
    
    
    var name:String = ""
    var vicinity:String = ""
    var rating:String = ""
    
    
}


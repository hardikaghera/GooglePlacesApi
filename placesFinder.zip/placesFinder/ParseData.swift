//
//  ParseData.swift
//  placesFinder
//
//  Created by hardik aghera on 24/12/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import Foundation

extension ViewController {
    
    // Parse Restuarants Data
    
    func parseRestaurantData(){
        
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=restuarant&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let restaurantData = fetchedData["results"]as? [NSDictionary]{
                        for item in restaurantData{
                            let result = Restaurants()
                            
                            if let name = item["name"] as? String {
                                result.name = name
                            }
                            if let vicinity = item["vicinity"] as? String{
                                result.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                result.rating = String(describing: rating)
                            }
                            
                            self.name.append(result.name)
                            self.Vicinity.append(result.vicinity)
                            self.Rating.append(result.rating)
                            print(result.name)
                            print(result.vicinity)
                            print(result.rating)
                        }
                        
                    }
                    
                    self.DetailsTableView.reloadData()
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    // Parse School data
    
    func parseSchoolData(){
        
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=school&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let restaurantData = fetchedData["results"]as? [NSDictionary]{
                        for item in restaurantData{
                            let result = Restaurants()
                            
                            if let name = item["name"] as? String {
                                result.name = name
                            }
                            if let vicinity = item["vicinity"] as? String{
                                result.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                result.rating = String(describing: rating)
                            }
                            
                            self.name.append(result.name)
                            self.Vicinity.append(result.vicinity)
                            self.Rating.append(result.rating)
                            print(result.name)
                            print(result.vicinity)
                            print(result.rating)
                        }
                        
                    }
                    
                    self.DetailsTableView.reloadData()
                
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    // Parse Gym Data
    
    func parseGymData(){
        
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=gym&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let restaurantData = fetchedData["results"]as? [NSDictionary]{
                        for item in restaurantData{
                            let result = Restaurants()
                            
                            if let name = item["name"] as? String {
                                result.name = name
                            }
                            if let vicinity = item["vicinity"] as? String{
                                result.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                result.rating = String(describing: rating)
                            }
                            
                            self.name.append(result.name)
                            self.Vicinity.append(result.vicinity)
                            self.Rating.append(result.rating)
                            print(result.name)
                            print(result.vicinity)
                            print(result.rating)
                        }
                        
                    }
                    
                    self.DetailsTableView.reloadData()
                    
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
    // parse Hospital Data
    
    func parseHospitalData(){
        
        let url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=37.785834,-122.406417&radius=4000&type=hospital&key=AIzaSyAdf62lKCoBTjVbYgiwQPLioc5TaX0FCVk"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            if(error != nil){
                print("Error")
                
            }else {
                do{
                    let fetchedData = try JSONSerialization.jsonObject(with: data!, options:.mutableLeaves) as! NSDictionary
                    
                    if let restaurantData = fetchedData["results"]as? [NSDictionary]{
                        for item in restaurantData{
                            let result = Restaurants()
                            
                            if let name = item["name"] as? String {
                                result.name = name
                            }
                            if let vicinity = item["vicinity"] as? String{
                                result.vicinity = vicinity
                            }
                            if let rating = item["rating"] {
                                result.rating = String(describing: rating)
                            }
                            
                            self.name.append(result.name)
                            self.Vicinity.append(result.vicinity)
                            self.Rating.append(result.rating)
                            print(result.name)
                            print(result.vicinity)
                            print(result.rating)
                        }
                        
                    }
                    
                    self.DetailsTableView.reloadData()
                    
                }
                catch{
                    print("Error 2")
                }
            }
        }
        task.resume()
    }

    
}
